BRAINISS ANDROID PROJECT

This is an Android Studio project wrapper for the existing Brainiss HTML learning app.
It packages the site locally inside the Android app, so the main learning screens can open without hosting the site online.

PROJECT CONTENTS
- app/src/main/assets/index.html: Brainiss website (classes 6-12, chapter notes, 5-question class quiz, study planner, 10 motivational lines)
- MainActivity.kt: Android WebView activity that loads the bundled app
- mipmap-*/ic_launcher.png: the new Brainiss home-screen app icon
- AndroidManifest.xml and Gradle build files

HOW TO BUILD AN APK
1. Install Android Studio on a computer from https://developer.android.com/studio
2. Extract the Brainiss-Android.zip file.
3. In Android Studio choose Open, then select the extracted Brainiss-Android folder.
4. Wait for Gradle sync to finish. Install Android SDK Platform 35 if Android Studio asks.
5. For a test install: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK is usually created at app/build/outputs/apk/debug/app-debug.apk.
7. Test it on multiple Android phones before sharing.

IMPORTANT
- This ZIP is Android Studio project source, not a ready-to-install APK.
- Building requires Android Studio, a compatible JDK, Gradle and Android SDK Platform 35.
- The Brainiss logo generated for this project is already connected as the Android launcher icon. Before Play Store release, prepare a privacy policy/data-safety declaration, store listing, content rating and test the app. Play Console publishing must be handled by an eligible adult account holder if the developer is under 18.
- Brainiss chapter lists are a general NCERT/CBSE-style guide; verify them against the current school syllabus and textbook edition.
